import pathlib, xml.etree.ElementTree as ET, zipfile, re
p=pathlib.Path(__file__).resolve().parent
html=(p/'app/src/main/assets/index.html').read_text()
manifest=(p/'app/src/main/AndroidManifest.xml').read_text()
main=(p/'app/src/main/java/com/hexpulse/arcade/MainActivity.java').read_text()
gradle=(p/'app/build.gradle').read_text()
ET.fromstring(manifest)
assert html.count('hpNativeDeath(gameMode,true)')==1
assert html.count("hpNativeDeath('duel',duelTurn===1)")==1
assert html.count('hpNativeRunStart();')==1
assert html.count('hpNativeDuelComplete();')==1
assert 'ca-app-pub-3940256099942544~3347511713' in manifest
assert 'com.google.android.gms:play-services-ads:25.5.0' in gradle
assert 'AD_MIN_GAP_MS = 45000L' in main
assert 'AdCadence.due(deathCount)' in main
assert 'HexPulseAds' in main
assert 'game.setWebViewClient' in main
print('V50 AdMob test source/bridge/manifest basic checks: PASS')
