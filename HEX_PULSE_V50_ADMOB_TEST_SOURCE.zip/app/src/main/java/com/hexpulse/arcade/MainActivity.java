package com.hexpulse.arcade;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final String TAG = "HexPulseStartup";
    // Keep the previous HTTPS origin: existing localStorage, when present, stays under the same origin.
    private static final String LOCAL_URL = "https://appassets.androidplatform.net/assets/index.html";
    private static final int PICK_BACKUP = 4001;
    private static final int SAVE_BACKUP = 4002;
    // OFFICIAL GOOGLE TEST ADS ONLY. Never publish this sample ID as a live unit.
    private static final String TEST_INTERSTITIAL_ID = "ca-app-pub-3940256099942544/1033173712";
    private static final String AD_PREFS = "hexpulse_test_ads_v1";
    private static final long AD_MIN_GAP_MS = 45000L; // avoid two ads back-to-back when deaths are rapid
    private final Handler adHandler = new Handler(Looper.getMainLooper());
    private SharedPreferences adPreferences;
    private InterstitialAd interstitial;
    private boolean adLoading = false;
    private boolean pendingAtDuelEnd = false;
    private boolean adShowing = false;
    private int sessionGeneration = 0;
    private int deathCount = 0;
    private long lastAdShownAt = 0;
    private WebView game;
    private ValueCallback<Uri[]> pendingFileCallback;
    private String pendingBackupJson;

    @Override
    public void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        try {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            immersiveSafely();
            adPreferences = getSharedPreferences(AD_PREFS, MODE_PRIVATE);
            deathCount = adPreferences.getInt("deaths", 0);
            lastAdShownAt = adPreferences.getLong("last_shown", 0L);
            startGame();
            initializeTestAds();
        } catch (Throwable error) {
            Log.e(TAG, "Application startup failed", error);
            showNativeError("HP-START", error);
        }
    }

    private void startGame() throws Exception {
        game = new WebView(this);
        game.setBackgroundColor(0xFF181228);
        game.setOverScrollMode(View.OVER_SCROLL_NEVER);
        game.setVerticalScrollBarEnabled(false);
        game.setHorizontalScrollBarEnabled(false);
        WebSettings settings = game.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setBlockNetworkLoads(true); // All game assets are embedded, with no server dependencies.

        game.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return !LOCAL_URL.equals(request.getUrl().toString());
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError error) {
                if (req.isForMainFrame()) {
                    String message = (error == null || error.getDescription() == null)
                            ? "Unknown WebView page error" : error.getDescription().toString();
                    Log.e(TAG, "Main page load failed: " + message);
                    showNativeError("HP-PAGE", new IllegalStateException(message));
                }
            }
            @Override
            public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
                boolean crashed = detail != null && detail.didCrash();
                Log.e(TAG, "WebView renderer terminated. crashed=" + crashed);
                // A renderer that exited may not be reused. Swap it for a native diagnostic screen.
                game = null;
                showNativeError("HP-RENDER", new IllegalStateException(
                        crashed ? "Android WebView render process crashed" : "Android removed the WebView renderer"));
                try { view.destroy(); } catch (Throwable ignored) { }
                return true;
            }
        });
        game.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
                pendingFileCallback = callback;
                Intent choose = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                choose.addCategory(Intent.CATEGORY_OPENABLE);
                choose.setType("application/json");
                choose.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try {
                    startActivityForResult(choose, PICK_BACKUP);
                } catch (ActivityNotFoundException exception) {
                    pendingFileCallback.onReceiveValue(null);
                    pendingFileCallback = null;
                    Toast.makeText(MainActivity.this, "Dosya seçici bulunamadı", Toast.LENGTH_SHORT).show();
                }
                return true;
            }
            @Override
            public boolean onConsoleMessage(ConsoleMessage message) {
                if (message.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e(TAG, "JavaScript: " + message.message());
                }
                return false;
            }
        });
        game.addJavascriptInterface(new BackupBridge(), "HexPulseBridge");
        game.addJavascriptInterface(new AdEventBridge(), "HexPulseAds");

        // loadDataWithBaseURL uses an HTTPS origin without invoking WebViewAssetLoader or
        // requesting any network connection. It retains localStorage / JS / WebAudio support.
        byte[] htmlBytes;
        try (InputStream input = getAssets().open("index.html");
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] block = new byte[8192];
            int count;
            while ((count = input.read(block)) != -1) output.write(block, 0, count);
            htmlBytes = output.toByteArray();
        }
        if (htmlBytes.length < 1000) throw new IllegalStateException("Oyun dosyası eksik veya boş");
        setContentView(game);
        game.loadDataWithBaseURL(LOCAL_URL,
                new String(htmlBytes, StandardCharsets.UTF_8),
                "text/html", "UTF-8", null);
        Log.i(TAG, "Game HTML loaded into Android WebView: " + htmlBytes.length + " bytes");
    }

    // Interstitials are displayed only on a game-over results screen, never during play.
    // Android's UI thread alone owns all Google Mobile Ads SDK calls.
    private void initializeTestAds() {
        new Thread(() -> {
            try {
                MobileAds.initialize(getApplicationContext(), status ->
                        runOnUiThread(this::preloadInterstitial));
            } catch (Throwable error) {
                Log.w(TAG, "AdMob test SDK unavailable; game still works", error);
            }
        }, "admob-test-init").start();
    }

    private void preloadInterstitial() {
        if (isFinishing() || isDestroyed() || adLoading || adShowing || interstitial != null) return;
        adLoading = true;
        try {
            InterstitialAd.load(this, TEST_INTERSTITIAL_ID,
                    new AdRequest.Builder().build(), new InterstitialAdLoadCallback() {
                        @Override
                        public void onAdLoaded(InterstitialAd loaded) {
                            adLoading = false;
                            interstitial = loaded;
                            Log.i(TAG, "Google TEST interstitial ready");
                        }
                        @Override
                        public void onAdFailedToLoad(LoadAdError error) {
                            adLoading = false;
                            interstitial = null;
                            Log.i(TAG, "Test ad unavailable; no interruption: " + error.getMessage());
                        }
                    });
        } catch (Throwable error) {
            adLoading = false;
            Log.w(TAG, "Failed to request test ad", error);
        }
    }

    private final class AdEventBridge {
        @JavascriptInterface
        public void onRunStart(String mode) {
            runOnUiThread(() -> {
                sessionGeneration++;
                if (!"duel".equals(mode)) pendingAtDuelEnd = false; // preserve a pending ad across duel player handoff
            });
        }
        @JavascriptInterface
        public void onDuelFinished() {
            runOnUiThread(() -> {
                if (pendingAtDuelEnd) {
                    pendingAtDuelEnd = false;
                    scheduleAdOnResultScreen();
                }
            });
        }
        @JavascriptInterface
        public void onDeath(String mode, boolean duelFinal) {
            runOnUiThread(() -> {
                deathCount++;
                adPreferences.edit().putInt("deaths", deathCount).apply();
                if (AdCadence.due(deathCount)) pendingAtDuelEnd = true;
                // Don't interrupt the hand-off between the two players of a local duel.
                if ("duel".equals(mode) && !duelFinal) return;
                if (!pendingAtDuelEnd) return;
                pendingAtDuelEnd = false;
                scheduleAdOnResultScreen();
            });
        }
    }

    private void scheduleAdOnResultScreen() {
        if (interstitial == null || adShowing) { preloadInterstitial(); return; } // no waiting or popups later
        if (System.currentTimeMillis() - lastAdShownAt < AD_MIN_GAP_MS) return;
        final int expectedGeneration = sessionGeneration;
        adHandler.postDelayed(() -> {
            // If the player already pressed Replay, don't interrupt the new game.
            if (expectedGeneration != sessionGeneration || game == null ||
                    isFinishing() || isDestroyed() || adShowing || interstitial == null) return;
            final InterstitialAd readyAd = interstitial;
            interstitial = null;
            readyAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                @Override public void onAdShowedFullScreenContent() {
                    adShowing = true;
                    lastAdShownAt = System.currentTimeMillis();
                    adPreferences.edit().putLong("last_shown", lastAdShownAt).apply();
                }
                @Override public void onAdDismissedFullScreenContent() {
                    adShowing = false;
                    immersiveSafely();
                    preloadInterstitial();
                }
                @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                    adShowing = false;
                    Log.w(TAG, "Test ad failed to display: " + error.getMessage());
                    preloadInterstitial();
                }
            });
            try { readyAd.show(this); }
            catch (Throwable error) {
                adShowing = false;
                Log.w(TAG, "Test ad show failed", error);
                preloadInterstitial();
            }
        }, 650L);
    }

    private void showNativeError(String code, Throwable cause) {
        final String detail = cause == null ? "Bilinmeyen hata" :
                cause.getClass().getSimpleName() + ": " + String.valueOf(cause.getMessage());
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (getResources().getDisplayMetrics().density * 22f);
        panel.setPadding(p, p, p, p);
        panel.setBackgroundColor(0xFF181228);
        TextView title = new TextView(this);
        title.setText("HEX PULSE — AÇILIŞ HATASI");
        title.setTextColor(0xFFFF6E78);
        title.setTextSize(22);
        panel.addView(title);
        TextView desc = new TextView(this);
        desc.setText("Uygulama kapanmak yerine hatayı gösterecek şekilde güncellendi.\n\n"
                + code + "\n" + detail + "\n\nBu ekranın fotoğrafını paylaşabilirsin.");
        desc.setTextColor(Color.WHITE);
        desc.setTextSize(15);
        desc.setPadding(0, p, 0, p);
        panel.addView(desc);
        Button copy = new Button(this);
        copy.setText("Hata bilgisini kopyala");
        copy.setOnClickListener(v -> {
            ClipboardManager manager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (manager != null) manager.setPrimaryClip(ClipData.newPlainText("HEX PULSE hata", code + "\n" + detail));
            Toast.makeText(this, "Hata bilgisi kopyalandı", Toast.LENGTH_SHORT).show();
        });
        panel.addView(copy);
        setContentView(panel);
    }

    private final class BackupBridge {
        @JavascriptInterface
        public void saveBackup(String json, String requestedFileName) {
            if (json == null || json.length() > 2_000_000) return;
            final String safeName = (requestedFileName == null ? "HEX_PULSE_YEDEK.json" : requestedFileName)
                    .replaceAll("[^a-zA-Z0-9_.-]", "_");
            runOnUiThread(() -> {
                pendingBackupJson = json;
                Intent create = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                create.addCategory(Intent.CATEGORY_OPENABLE);
                create.setType("application/json");
                create.putExtra(Intent.EXTRA_TITLE, safeName);
                try {
                    startActivityForResult(create, SAVE_BACKUP);
                } catch (ActivityNotFoundException exception) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "Kaydetme penceresi açılamadı", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_BACKUP) {
            if (pendingFileCallback != null) {
                Uri chosen = (resultCode == RESULT_OK && data != null) ? data.getData() : null;
                pendingFileCallback.onReceiveValue(chosen == null ? null : new Uri[]{chosen});
                pendingFileCallback = null;
            }
        } else if (requestCode == SAVE_BACKUP) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
                    if (output == null) throw new IllegalStateException("Dosya açılamadı");
                    output.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "HEX PULSE yedeği kaydedildi", Toast.LENGTH_SHORT).show();
                } catch (Exception exception) {
                    Toast.makeText(this, "Yedek kaydedilemedi: " + exception.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupJson = null;
        }
        immersiveSafely();
    }

    private void immersiveSafely() {
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                getWindow().setDecorFitsSystemWindows(false);
                if (getWindow().getInsetsController() != null) {
                    getWindow().getInsetsController().hide(
                            android.view.WindowInsets.Type.statusBars() | android.view.WindowInsets.Type.navigationBars());
                }
            } else {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (Throwable exception) {
            Log.w(TAG, "Immersive mode unavailable on this device", exception);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
        immersiveSafely();
    }

    @Override
    protected void onPause() {
        if (game != null) {
            try { game.evaluateJavascript("document.getElementById('pause')?.click()", null); } catch (Throwable ignored) { }
            try { game.onPause(); } catch (Throwable ignored) { }
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        immersiveSafely();
        if (game != null) {
            try { game.onResume(); } catch (Throwable exception) { showNativeError("HP-RESUME", exception); }
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (game != null) {
            try { game.evaluateJavascript("document.getElementById('pause')?.click()", null); } catch (Throwable ignored) { }
        }
        new AlertDialog.Builder(this)
                .setMessage("HEX PULSE oyunundan çıkılsın mı?")
                .setNegativeButton("Vazgeç", (dialog, which) -> immersiveSafely())
                .setPositiveButton("Çık", (dialog, which) -> finish())
                .show();
    }

    @Override
    protected void onDestroy() {
        if (pendingFileCallback != null) pendingFileCallback.onReceiveValue(null);
        if (game != null) {
            try { game.removeJavascriptInterface("HexPulseBridge"); game.removeJavascriptInterface("HexPulseAds"); } catch (Throwable ignored) { }
            try { game.destroy(); } catch (Throwable ignored) { }
            game = null;
        }
        super.onDestroy();
    }
}
