# HEX PULSE V4.9 — AdMob 2 ölüm / reklam (TEST)

Bu paket V4.9 Violet Rush oyun motorunun aynı halini korur. APK için tek fark: gerçek ölüm bitişlerinden sonra yerel JavaScript köprüsü üzerinden Android AdMob test reklamına haber verilmesidir.

## Kurallar
- 1. ölüm: reklam çıkmaz.
- 2. ölüm: oyun bittikten SONRA, sonuç ekranında reklam hazırsa geçiş reklamı çıkar.
- 3. ölüm: reklam çıkmaz. 4. ölüm: aynı kural sürer.
- Günlük 60 saniye başarıyla tamamlamak ve Sonsuz Mod 500 saniye finalini bitirmek ölüm sayılmaz.
- Yerel 1v1 iki oyuncunun sırası arasında reklam göstermez; gerekiyorsa maçın sonuç ekranında gösterir.
- Reklam hazır değilse oyun bekletilmez, reklam atlanır. 45 saniyelik minimum gösterim aralığı vardır.
- Ölümler uygulama kapatılıp açıldıktan sonra da sayılır.
- HTML dosyası tek başına açılırsa reklam SDK'sı yoktur, oyun normal çalışır.
- Oyuncuya reklam izlediği için coin VERİLMEZ. Bu sadece geçiş reklamıdır.

## Sadece Google test kimlikleri
- AdMob SAMPLE app id `ca-app-pub-3940256099942544~3347511713`
- AdMob TEST interstitial `ca-app-pub-3940256099942544/1033173712`
Gerçek reklam geliri oluşturmaz. Google Play'de yayınlamadan önce kendi kimlikleriniz, kullanıcı rızası, gizlilik politikası, Play Data Safety ve reklam ayarları tamamlanmalıdır. Reklam bir ağ bağlantısı varsa yüklenir; oyun çevrimdışı çalışmaya devam eder.

## Telefondan APK derlemesi
1. Bu ZIP'i GitHub deposunun kök dizinine dosya olarak yükleyin; önceki ZIP'leri SİLMEYİN.
2. `.github/workflows/build-ads-test.yml` dosyası oluşturup `HEX_PULSE_V50_ADMOB_TEST_GITHUB_BUILD.yml` içeriğini ekleyin.
3. Actions > `HEX PULSE - V4.9 2 Deaths AdMob TEST` > Run workflow.
4. Başarılı olunca `HEX-PULSE-V50-TEST-ADS-APK` artifact'indeki APK'yı açın.
5. Ayrı paket kimliği `com.hexpulse.arcade.violetads`: mevcut V4.9'un yanına kurulur.

NOT: Kod kontrolü yapıldı, bu ortamda Android SDK olmadığından gerçek APK derlemesi ve cihaz üstü reklam gösterimi henüz yapılmadı.
