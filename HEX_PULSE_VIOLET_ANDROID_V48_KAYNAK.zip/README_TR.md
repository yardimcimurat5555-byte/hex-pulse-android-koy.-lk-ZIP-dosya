# HEX PULSE — Violet Rush Android test (V4.8)

Bu paket **kaynak kodudur; APK değildir**. Son Violet Rush + ORBITAL CIRCUIT görsel test HTML dosyası oyun mantığı değiştirilmeden Android WebView içine yerleştirilmiştir.

## Neler değişti?

- Oyunun adı **HEX PULSE** olarak kaldı. Test uygulama adı **HEX PULSE Violet**.
- Renkler: koyu gece moru `#181228`, lavanta `#9B8CE8`, mercan `#FF6E78`.
- Yeni orijinal yörünge/enerji çekirdeği uygulama ikonu, Android 12+ başlangıç simgesi ve eski Android sürümlerine açılış arka planı.
- Önceki Android APK'nı korumak için **applicationId**: `com.hexpulse.arcade.violetpreview` (ayrı test uygulaması).
- Oyun kaynağı: `app/src/main/assets/index.html`, birebir Violet Rush HTML.
- Kaynak tabanı: telefonda açıldığı doğrulanan **Android açılış düzeltmeli** WebView uygulaması.
- Yalnızca görünüm ve Android kaynakları değişti. Mevcut oyun fiziği, üçgen çarpışması, rekorlar, 500 saniyelik final, görev/mağaza ve yerel 1v1 kuralları aynı.

## GitHub ile APK oluştur (telefondan)

1. `HEX_PULSE_VIOLET_ANDROID_V48_KAYNAK.zip` dosyasını mevcut GitHub deponun **Code → Add file → Upload files** bölümüne yükle ve Commit changes yap. ZIP'i depoda açmana gerek yok.
2. `.github/workflows/build-violet-apk.yml` adlı yeni dosyayı oluştur. İçine verilen `HEX_PULSE_VIOLET_GITHUB_BUILD.yml` dosyasının içeriğini yapıştır, commit et.
3. **Actions → HEX PULSE - Violet Rush APK → Run workflow** seç.
4. Yeşil tikten sonra çalışmanın **Artifacts** bölümündeki `HEX-PULSE-VIOLET-TEST-APK` dosyasını indir. Bu artifact bir ZIP'tir; içindeki `.apk`yi çıkar ve yükle.
5. Ana ekranda **HEX PULSE Violet** simgesinden başlat. İlk açılış, ses, döndürme, günlük görevler, rekor kayıtları, yerel 1v1 ve yedek al/geri yükle seçeneklerini dene.

**ÖNEMLİ:** Daha önce açılabilen normal HEX PULSE APK'sını silme. Bu yeni test uygulaması yanına kurulur ve **ayrı kayıt alanı** kullanır. Coin/rekorlarını taşımak istersen eski uygulamadan oyun içi JSON yedeği indirip Violet Test içinden geri yükle; kayıtlar otomatik geçmez.

**ÖNEMLİ:** APK'ların GitHub Actions tarafından derlenmesi gerekir. Bu ortamda Android SDK/Gradle APK derlemesi yapılmamıştır. Sonraki yayın sürümü için imzalı AAB, benzersiz kalıcı uygulama kimliği ve Play Console hazırlıkları ayrıca gerekecek. `debug.apk` Google Play'e yüklenmez.

## Kod testleri

- `python3 test_project.py`
- GitHub workflow otomatik: `gradle --no-daemon :app:assembleDebug`

İletişim veya Firebase izni gerektirmez; oyun çevrimdışı çalışır.
