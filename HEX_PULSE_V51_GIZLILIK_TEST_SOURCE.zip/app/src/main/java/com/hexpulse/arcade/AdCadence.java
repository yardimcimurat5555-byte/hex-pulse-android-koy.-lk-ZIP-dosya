package com.hexpulse.arcade;

/** One interstitial eligibility event after each pair of actual deaths. */
public final class AdCadence {
    private AdCadence() { }
    public static boolean due(int actualDeaths) {
        return actualDeaths > 0 && actualDeaths % 2 == 0;
    }
}
