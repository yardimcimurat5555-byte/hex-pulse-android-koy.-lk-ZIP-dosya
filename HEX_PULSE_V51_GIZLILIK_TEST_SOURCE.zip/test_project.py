from pathlib import Path
import xml.etree.ElementTree as ET, re
p = Path(__file__).resolve().parent
h = (p/'app/src/main/assets/index.html').read_text()
m = (p/'app/src/main/AndroidManifest.xml').read_text()
a = (p/'app/src/main/java/com/hexpulse/arcade/MainActivity.java').read_text()
g = (p/'app/build.gradle').read_text()
ET.fromstring(m)
assert 'android:value="${admobAppId}"' in m
assert 'targetSdk 36' in g and 'user-messaging-platform:4.0.0' in g
assert 'play-services-ads:25.5.0' in g
assert "applicationIdSuffix '.privacytest'" in g
assert 'HEX_PRIVACY_URL' in g and 'requestedRelease' in g
assert 'ca-app-pub-3940256099942544' not in a
assert 'BuildConfig.INTERSTITIAL_AD_UNIT_ID' in a
assert 'requestConsentInfoUpdate' in a and 'canRequestAds()' in a
assert 'showPrivacyOptionsForm' in a and 'openPolicy()' in a
assert 'HexPulsePrivacy' in a
assert h.count('id="privacyOptions"')==1 and h.count('id="privacyPolicy"')==1
assert h.count('hpNativeDeath(gameMode,true)')==1
assert h.count("hpNativeDeath('duel',duelTurn===1)")==1
assert h.count('hpNativeDuelComplete();')==1
assert 'AD_MIN_GAP_MS = 45000L' in a
print('V5.1 release-prep structure: PASS')

assert 'publisherTestAppId' in g
assert 'requestedRelease ? realInterstitial : sampleInterstitial' in g
assert "requestedRelease ? realAppId : publisherTestAppId" in g
print('Real app ID + sample ad unit configuration: PASS')
