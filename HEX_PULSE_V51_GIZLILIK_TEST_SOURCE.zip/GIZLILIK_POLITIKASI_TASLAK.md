# HEX PULSE — Gizlilik Politikası (YAYIN ÖNCESİ TASLAK)

**DURUM: Taslak. Bu belge geliştirici iletişim bilgileri ve gerçek veri denetimi tamamlanmadan yayınlanmamalıdır.**

**Uygulama:** HEX PULSE (Android)  
**Yayıncı:** [GOOGLE PLAY GELİŞTİRİCİ ADI]  
**Gizlilik iletişim adresi:** [İLETİŞİM E-POSTASI]  
**Güncelleme tarihi:** [YAYIN TARİHİ]

## 1. Oyun kayıtları
Oyun; rekor, günlük görev ilerlemesi, Pulse Coin bakiyesi, kozmetik satın alımları, rozetler ve ses ayarlarını cihaz üzerinde tutar. Oyuncu bu kayıtları kendi isteğiyle JSON dosyası olarak dışa aktarabilir veya geri yükleyebilir. Çevrimiçi hesap, arkadaş eşleştirme ve sunucu tabanlı liderlik tablosu mevcut sürümde bulunmamaktadır. Android işletim sistemi ayarlarına bağlı olarak cihaz yedekleme servisleri uygulama verilerini yedekleyebilir.

## 2. Reklamlar
Oyun Google AdMob SDK'sını kullanır. Reklam gösterimi ve ölçümü kapsamında Google ve iş ortakları, cihaz tanımlayıcıları, reklam etkileşimleri, yaklaşık konum çıkarımları, IP adresi ve diğer tanılama verileri gibi bilgileri kendi politikaları çerçevesinde işleyebilir. Kullanılan gerçek SDK ve reklam ayarları yayın öncesinde ayrıca gözden geçirilmelidir. Google'ın [Reklam Teknolojileri](https://policies.google.com/technologies/ads) ve [Gizlilik Politikası](https://policies.google.com/privacy) sayfalarına bakılabilir.

## 3. Kullanıcı tercihleri
Gerekli bölgelerde Google User Messaging Platform (UMP) aracılığıyla bir gizlilik bildirimi sunulabilir. Kullanıcının bölgesine ve sunulan mesaj türüne göre, oyun ayarlarından reklam gizlilik tercihleri yeniden açılabilir. Reklam rızasının gerekli olduğu yerlerde izin durumu uygun değilse reklam istenmez.

## 4. Verilerin kullanım amacı
Yerel oyun ilerlemesini korumak, isteğe bağlı yedekleme sağlamak, reklam sunmak ve reklam performansını ölçmek. Üçüncü taraf SDK'ların uyguladığı veri saklama süreleri ilgili sağlayıcı politikalarına tabidir.

## 5. Saklama ve silme
Yerel oyun kayıtları uygulamanın verileri silinene veya kullanıcı oyunu kaldırana kadar cihazda kalabilir; kullanıcı tarafından çıkarılmış JSON yedekleri ayrıca silinmelidir. Reklam SDK'sının tuttuğu verilerin yönetimi ve silme başvuruları ilgili sağlayıcının politikaları uyarınca yürütülür. Yayıncının veri silme/başvuru iletişimi: [İLETİŞİM E-POSTASI].

## 6. İletişim
Gizlilikle ilgili sorular için: [İLETİŞİM E-POSTASI].

## Yayın öncesi doğrulama listesi
- [ ] Geliştirici adı, iletişim adresi, güncelleme tarihi eklendi.
- [ ] Play Console Data Safety yanıtları gerçek AdMob SDK veri kategorileriyle eşleştirildi.
- [ ] Politika herkese açık, HTTPS sayfada yayımlandı ve uygulamaya eklendi.
- [ ] Google AdMob Privacy & Messaging panelinde gerekli mesajlar yayımlandı.
- [ ] Çocuklara yönelik hedef kitle, ülke mevzuatı ve reklam ayarları doğrulandı.
- [ ] Android işletim sistemi yedeklemesinin etkileri doğrulandı.
