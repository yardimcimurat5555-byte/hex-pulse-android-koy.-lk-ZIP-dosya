# HEX PULSE V5.1 — Yayımlanan rıza mesajı için güvenli APK testi

Bu paket **V5.0'dan ayrı** Android test APK'sı üretir. Çalışan APK'yı silmeyin.

## Test reklamları / gerçek rıza mesajı
- AdMob *uygulama kimliği* senin HEX PULSE AdMob uygulamana aittir: `ca-app-pub-1582223965286404~6190968745` (genel SDK yapılandırma kimliği, parola değil).
- Reklam **birim kimliği Google'ın test kimliğidir**. Bu APK gerçek reklam geliri üretmez.
- UMP yayımladığın gizlilik mesajını sorgular. Türkiye'de rıza ekranının otomatik görünmemesi normal olabilir; mesajın coğrafi hedeflemesine bağlıdır.
- Ayarlar > Gizlilik Politikası düğmesi için `PRIVACY_POLICY_URL` GitHub deposu değişkenine gerçek `https://` adresini girmelisin.
- UMP rızası alınması gereken bölgelerde reklam yüklemeyi `canRequestAds()` durumuna bağlar.

## Telefonla GitHub kurulumu
1. `HEX_PULSE_V51_GIZLILIK_TEST_SOURCE.zip` dosyasını **GitHub deponun ana klasörüne** yükle; ZIP'i açma.
2. `.github/workflows/build-v51-privacy.yml` dosyasını oluştur; yanında verilen YAML kodunun tamamını yapıştır.
3. `Settings → Secrets and variables → Actions → Variables` altında **isteğe bağlı** `PRIVACY_POLICY_URL` ekle. Değeri GitHub Pages gizlilik politikanın doğrulanmış HTTPS adresi olsun. Yayın öncesi zorunlu.
4. Commit sonrası Actions'ta **HEX PULSE V5.1 - Gizlilik TEST APK** derlemesi otomatik başlamalı. Yeşil tik olduğunda `HEX-PULSE-V51-GIZLILIK-TEST-APK` çıktısını indir ve ZIP içindeki APK'yı kur.
5. Sonsuz Mod'u aç; oyun çalışmalı. Reklamlar hâlâ **test reklamları** olmalı. GDPR hedefindeki cihazlarda rıza akışını ayrıca test et. Türkçe bölgedeyken ekranın çıkmaması tek başına hata değildir.

**Eski çalışan V5.0 APK'yı kaldırma.** Bu APK farklı uygulama kimliği (`com.hexpulse.arcade.privacytest`) ile kurulur. Kayıtları otomatik paylaşmaz.

## Yayın paketine geçmeden önce
- Üretim reklam birimini ve gerçek uygulama kimliğini yalnızca imzalı release AAB'de kullan; UMP iznini doğrula.
- Gizlilik politikası, Data Safety, reklam beyanları, test süreci ve doğru upload imzası tamamlanmalı.
- Keystore ve şifrelerini herkese açık GitHub'a veya sohbetlere koyma.

## Önemli
- `GIZLILIK_POLITIKASI_TASLAK.md` **yayınlanmaya hazır değildir**; yayıncı kimliği, iletişim ve veri denetimi gerektirir.
- GitHub kaynak ZIP / test APK / imzalı AAB farklı şeylerdir. Google Play'e yüklenmesi gereken release AAB'dir.
- Release'den önce tüm Play Console uygulama içeriği, reklam bildirimi, hedef kitle, Data Safety, içerik derecelendirmesi, mağaza ekran görüntüleri ve gerekli test süreci tamamlanmalıdır.
- Kaynak dosyanın sözdizimi ve yapı testleri burada yapılır. Gerçek Android APK/AAB derlemesi yalnızca GitHub Actions'ta başarılı olduğunda doğrulanır.

## Gizlilik sayfasını Google Play için yayımlama
- Paketteki `GIZLILIK_POLITIKASI_YAYIN_TASLAK.html` dosyasına **gerçek yayıncı adı, iletişim e-postası ve tarihini yazın**. Veri kategorilerini gerçek uygulama/SDK ile doğrulayın.
- Bu dosyayı GitHub deposunun `docs/privacy.html` yoluna koyun, GitHub **Settings → Pages** ile `main /docs` üzerinden yayımlayın.
- Sayfanın gerçekten herkese açık `https://` adresini `PRIVACY_POLICY_URL` değişkenine girin.
- Uyarı: Test taslağını boş köşeli parantezli alanlarla Google Play'e göndermeyin.
