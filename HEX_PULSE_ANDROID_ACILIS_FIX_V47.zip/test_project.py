#!/usr/bin/env python3
"""HEX PULSE V4.7 offline WebView package verification (no network required)."""
from pathlib import Path
import subprocess, re, xml.etree.ElementTree as ET, shutil
root=Path(__file__).resolve().parent
html=(root/'app/src/main/assets/index.html').read_text(encoding='utf-8')
manifest=root/'app/src/main/AndroidManifest.xml'
java=(root/'app/src/main/java/com/hexpulse/arcade/MainActivity.java').read_text(encoding='utf-8')
ET.parse(manifest)
assert 'INTERNET' not in manifest.read_text(encoding='utf-8'), 'Unexpected internet permission'
for item in ('HexPulseBridge','saveBackup','function pauseGame','function restoreMenu',"gameMode==='duel'",'CORE_FINAL_END=500'):
    assert item in html, f'Missing core game or backup feature: {item}'
assert 'setJavaScriptEnabled(true)' in java
assert 'loadDataWithBaseURL' in java
assert 'onRenderProcessGone' in java
assert 'showNativeError' in java
assert len(re.findall(r'<script(?:\s[^>]*)?>', html))==1, 'Expected one inline JS script'
match=re.search(r'<script(?:\s[^>]*)?>(.*?)</script>',html,re.S)
assert match, 'No inline JS'
syntax_file=root/'_test_game_syntax.js'
syntax_file.write_text(match.group(1),encoding='utf8')
try:
    node=shutil.which('node')
    if node:
        subprocess.run([node,'--check',str(syntax_file)],check=True)
    else:
        print('Node.js unavailable: JavaScript syntax step skipped')
finally:
    syntax_file.unlink(missing_ok=True)
print('PASS: AndroidManifest XML, offline permissions, game features, bridge and JavaScript syntax')
