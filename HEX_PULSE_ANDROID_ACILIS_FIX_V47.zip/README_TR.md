# HEX PULSE V4.7 Android Açılış Onarımı

Bu kaynak paketi, ilk debug APK'nın Android'de açılır açılmaz kapanması raporuna yönelik ayrı bir deneme sürümüdür. **Kesin kök neden tespit edildiği iddia edilmez**: cihazdan Logcat çökme kaydı henüz alınmadı.

## Değişiklikler
- Oyun HTML dosyası SHA-256 düzeyinde birebir korundu (V4.7).
- AndroidX WebKit AssetLoader bağımlılığı çıkarıldı. Oyunun tek dosyalı HTML'si, Android'in yerleşik WebView'inde geçerli HTTPS origin ile `loadDataWithBaseURL` kullanılarak açılıyor.
- Android başlangıç ve WebView render hataları için uygulama içi `HP-START`, `HP-PAGE`, `HP-RENDER` tanı ekranları eklendi; desteklenmeyen tam ekran API hataları yakalanıyor.
- JSON dosya yedeği alma/geri yükleme, tam ekran, ses ve oyun özellikleri korundu.
- `versionCode=2`, `versionName=0.9.1-startup-fix`.

## GitHub telefon kurulumu
1. `HEX_PULSE_ANDROID_ACILIS_FIX_V47.zip` dosyasını mevcut özel depoya, eskisini silmeden yükle.
2. `.github/workflows/build-apk.yml` dosyasını aç, kalem simgesiyle içeriğini `HEX_PULSE_GITHUB_ACILIS_FIX_BUILD.yml` dosyasındaki kodla tamamen değiştirip commit et.
3. Actions'ta yeni işin yeşil tik almasını bekle ve `HEX-PULSE-STARTUP-FIX` artifaktını indir.
4. Artifakt ZIP içinden `HEX-PULSE-STARTUP-FIX.apk` dosyasını çıkart.
5. **Önce eski çöken debug APK'yı kaldır**: GitHub her çalışmada farklı geçici debug anahtarı kullanabileceği için yenisi mevcut uygulamanın üzerine kurulmayabilir. Eski APK'da önemli kayıt varsa önce yedekle.
6. Yeni APK'yı kur. Açılırsa Sonsuz ve Günlük Mod ile müzik/kayıtları test et.
7. Hâlâ kapanıyorsa Android **Ayarlar > Uygulamalar > Android System WebView** (ve Chrome) güncelliğini kontrol et. `HP-...` hata ekranı görünürse ekran görüntüsünü paylaş. **Hiç ekran çıkmadan kapanırsa** kesin teşhis için Logcat hata kaydı gerekir.

APK doğrudan bu ortamda derlenemedi. GitHub Actions derlemesi sonucu doğrulanmalıdır.
