# HEX PULSE V4.7 — Android APK Test Paketi

Bu paket bir **APK değildir**. Google Actions ile telefona kurulabilir APK üretmeye hazır Android kaynaklarıdır. Oyun V4.7 HTML'si ve MainActivity Java kodu önceki paketten **değiştirilmeden** aktarılmıştır; yalnızca test betiği ve derleme yönergeleri eklenmiştir.

## 100% Android telefondan, PC ve Termux olmadan

1. GitHub hesabına gir: https://github.com/new . Yeni depo oluştur: `hex-pulse-android` ve **Private** seç. README'yi burada açman gerekmez.
2. Bu dosyayı (`HEX_PULSE_V47_ANDROID_APK_KAYNAK.zip`) telefonuna indir. GitHub deposunda `Add file > Upload files` seçeneği ile ZIP'i açmadan yükle ve commit et.
3. İkinci dosya (`HEX_PULSE_V47_GITHUB_APK_BUILD.yml`) içeriğini kopyala. GitHub deposunda `Add file > Create new file` ile **tam** dosya yolunu `.github/workflows/build-apk.yml` yap; metni yapıştır ve commit et. Mobil arayüz zor gelirse Chrome > Masaüstü sitesi ile dene.
4. `Actions` sayfasından `HEX PULSE V4.7 - Android Test APK` çalışmasını aç. `Run workflow` düğmesi görünürse kullan; aksi halde workflow dosyasını kaydetmek de push tetikler.
5. İşlem başarılı olursa `Artifacts` bölümünde `HEX-PULSE-V47-ANDROID-APK` isimli çıktıyı indir. ZIP açıldıktan sonra `HEX-PULSE-V47-test.apk` dosyasını telefonuna yükle. Android'de gerekli ise Chrome/Dosyalar için “Bu kaynaktan izin ver” seçeneğini onayla.

### Dikkat
- GitHub'a yüklediğin dosyanın adı ve workflow yolunun yazımı birebir aynı olmalıdır.
- APK **debug imzalı test** dosyasıdır. Google Play'e doğrudan yüklenemez.
- Gelecekte GitHub tarafından farklı test anahtarıyla imzalanırsa eskisinin üzerine kurulamayabilir. Güncellemeden önce oyun Ayarlar > Yedekle bölümünden JSON yedeğini sakla.
- HTML sürümündeki kayıtlar uygulamaya otomatik taşınmaz. HTML'de JSON dışa aktar, uygulamada geri yükle.
- Depo özel olduğu için oyunun kaynaklarını herkese açık yayınlamak zorunda değilsin.
- Oyunun arka ucu yok, çevrimiçi 1v1 yok; yerel 1v1 coin vermez.
- Bu çalışma paketinin kaynak/JS/Manifest kontrolleri yapıldı. APK Android SDK olmadan burada derlenmedi; GitHub Actions derlemesini ve cihaz testini tamamlamak gerekiyor.

## Paket bilgileri
- `com.hexpulse.arcade`, minSdk 24, targetSdk/compileSdk 36.
- Java 17, Gradle 8.13, AGP 8.13.2; AndroidX WebKit 1.16.0.
- Android WebView AssetLoader içinde çevrimdışı oyun, tam ekran, native JSON dosya seçici.
- 500 sn final, görevler, coin mağazası, Günlük Turbo, Yerel 1v1.
